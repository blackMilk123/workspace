package com.sunrise.common;

public abstract class BaseServiceImpl<T> extends com.zhangzlyuyx.fastssm.base.BaseServiceImpl<T> implements BaseService<T> {

}
