package com.sunrise.common;

public interface BaseService<T> extends com.zhangzlyuyx.fastssm.base.BaseService<T>  {

}
