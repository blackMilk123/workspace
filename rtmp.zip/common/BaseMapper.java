package com.sunrise.common;

public interface BaseMapper<T> extends com.zhangzlyuyx.fastssm.base.BaseMapper<T> {

}
