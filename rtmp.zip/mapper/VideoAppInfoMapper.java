package com.sunrise.dao;

import com.sunrise.model.VideoAppInfo;

/**
 * 视频监控应用信息 数据访问
 * video_appinfo
 */
public interface VideoAppInfoMapper extends com.sunrise.common.BaseMapper<VideoAppInfo> {

}
