package com.sunrise.yssdk;

public class SdkReturnMapList extends SdkReturn<SdkMapList> {

	private static final long serialVersionUID = 5028558329723033996L;
}
