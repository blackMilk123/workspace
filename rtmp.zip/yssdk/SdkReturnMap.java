package com.sunrise.yssdk;

public class SdkReturnMap extends SdkReturn<SdkMap> {

	private static final long serialVersionUID = 8336134969479362933L;

}
