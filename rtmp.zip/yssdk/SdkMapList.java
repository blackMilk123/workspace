package com.sunrise.yssdk;

import java.util.ArrayList;

/**
 * Sdk map 集合
 * @author zhangzhilong
 *
 */
public class SdkMapList extends ArrayList<SdkMap> {

	private static final long serialVersionUID = -2068392881158962605L;

	
}
